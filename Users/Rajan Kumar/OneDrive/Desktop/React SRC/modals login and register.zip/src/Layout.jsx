import Header from "./Components/Header"
import LoginBtn from "./Components/LoginBtn";

const Layout=()=>{
    return(
        <>
          
         <Header/>
         <LoginBtn/>


        </>
    )
}

export default Layout;